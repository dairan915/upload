The XMP Toolkit SDK needs zlib.
This release uses zlib Version 1.2.8






To get zlib:





1. Obtain a copy of the zlib source code (not the compiled dll)

   
	from http://www.zlib.net/

   
	(download links at the time of writing were at the bottom)

   




2. Place all top-level .c and .h files of the tar/zip you downloaded

   
	directly in .../third-party/zlib



   


